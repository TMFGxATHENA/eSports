<!-- footer.php -->
</div> <!-- End of content -->
        <footer>
            <p>© 2024 Furious eSports. All rights reserved.</p>
        </footer>
    </div> <!-- End of container -->
</body>
</html>
